# CSE535_HealthUI
Assignment 2: Health Monitoring UI

Jacob Wilkens

	JWilkens app for Health Monitoring UI 

		API 29 w/ Nexus 3a used to test. 

	databases folder for Flask Server

	Please ensure that you give the app permissions for files!! It doesn't ask you to in the emulator, just blocks it right away!
	

Demo at: 
	https://youtu.be/-h6VmyWHrus